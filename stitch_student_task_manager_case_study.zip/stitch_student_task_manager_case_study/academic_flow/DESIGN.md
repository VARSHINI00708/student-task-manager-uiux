---
name: Academic Flow
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#464555'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#684000'
  on-tertiary: '#ffffff'
  tertiary-container: '#885500'
  on-tertiary-container: '#ffd4a4'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 32px
---

## Brand & Style
The design system is built for the high-achieving student who requires a calm, structured environment to manage cognitive load. The brand personality is **reliable, encouraging, and organized**. 

The visual style follows a **Modern Corporate** aesthetic with a lean towards **Minimalism**. It prioritizes high legibility and functional clarity over decorative elements. By utilizing significant whitespace and a focused color palette, the UI minimizes distractions, allowing the user to enter a "flow state" for academic productivity. The interface feels academic-friendly—structured like a premium notebook but enhanced with the fluid interactions of a modern SaaS tool.

## Colors
This design system utilizes a purposeful, semantic color palette to guide the student’s attention.

- **Primary (Indigo):** Used for main actions, active states, and navigation. It represents focus and intelligence.
- **Success (Mint Green):** Exclusively for completed tasks and progress milestones to provide a dopamine-hit of accomplishment.
- **Warning (Amber):** Reserved for impending deadlines and high-priority items.
- **Surface & Background:** A soft gray-white in light mode to reduce eye strain during long study sessions. In dark mode, a Deep Navy is used to maintain depth and contrast without the harshness of pure black.

## Typography
**Inter** is the sole typeface for this design system to ensure maximum cross-platform consistency and readability. 

The hierarchy is strictly enforced:
- **Display and Headlines** use tighter letter-spacing and heavier weights to anchor the page.
- **Body** text uses a standard weight for long-form task descriptions.
- **Labels** use uppercase or semi-bold weights at smaller sizes for metadata like "Due Dates" or "Course Codes."
- On mobile devices, headline sizes scale down slightly to prevent awkward text wrapping in narrow task cards.

## Layout & Spacing
The design system employs a **Fluid Grid** model based on an 8px square rhythm. 

- **Mobile:** A 4-column grid with 16px margins and 16px gutters.
- **Desktop/Tablet:** A 12-column grid with a max-width container of 1200px to maintain readability. 

Vertical spacing should follow the `md` (16px) unit for grouping related items (e.g., a task title and its subtasks) and the `lg` (24px) unit for separating distinct sections (e.g., "Today" vs "Tomorrow").

## Elevation & Depth
Depth is conveyed through **Tonal Layers** and **Ambient Shadows**.

1.  **Level 0 (Background):** Neutral Soft Gray (#F9FAFB).
2.  **Level 1 (Cards/Surface):** Pure White (#FFFFFF) with a very soft, diffused shadow (0px 4px 20px rgba(0,0,0,0.04)). This is the primary container for tasks.
3.  **Level 2 (Active/Floating):** Used for Modals or Floating Action Buttons (FABs). These feature a slightly more pronounced shadow (0px 8px 30px rgba(79, 70, 229, 0.15)) using a primary-tinted shadow to reinforce the brand color.

Avoid heavy black shadows; the goal is to create a "paper-on-table" feel that is light and airy.

## Shapes
The shape language is defined by **Rounded** corners to evoke a friendly and modern feel.

- **Standard Cards/Inputs:** 0.5rem (8px) - 0.75rem (12px) for most UI containers.
- **Large Components (Modals/Main Containers):** 1rem (16px) for `rounded-lg`.
- **Buttons/Chips:** Use the `rounded-xl` (1.5rem) or full pill-shape for interactive elements to distinguish them from static containers.

## Components

### Buttons
- **Primary:** Indigo background, white text, pill-shaped. High emphasis.
- **Secondary:** Light Indigo tint background with Indigo text. Low emphasis.
- **Ghost:** No background, Indigo text. Used for less frequent actions like "Add Subtask."

### Task Cards
- Cards feature a 12px corner radius.
- Use a 4px left-border accent color to denote category or priority (e.g., Amber for high priority).
- Include a circular checkbox on the left for quick completion.

### Chips & Tags
- Used for course names (e.g., "MATH 101").
- Small text, 12px height, pill-shaped with a light-gray background to stay unobtrusive.

### Input Fields
- Fields are outlined with a 1px border (#E5E7EB).
- On focus, the border transitions to Primary Indigo with a soft 2px glow.

### Progress Indicators
- Linear progress bars for "Subject Mastery" or "Daily Goals."
- Uses the Success Mint Green for the fill color.

### Iconography
- Use "Outlined" style icons with a 2px stroke. 
- Icons should be functional—clock for deadlines, book for courses, and check-circle for completion.